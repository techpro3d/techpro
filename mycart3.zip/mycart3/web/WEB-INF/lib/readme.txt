You will need the following JARs from the Spring 2.5.4 distribution:

spring.jar
spring-webmvc.jar
cglib-nodep-2.1_3.jar
commons-logging.jar
jstl.jar
standard.jar

You will need the following JARs from the Spring Web Flow 2.0 distribution:

spring-binding-2.0.0.jar
spring-js-2.0.0.jar
spring-webflow-2.0.0.jar

You will need the following additional JARs:

ognl-2.6.9.jar from http://www.ognl.org/
sitemesh-2.3.jar from http://www.opensymphony.com/sitemesh/download.action
